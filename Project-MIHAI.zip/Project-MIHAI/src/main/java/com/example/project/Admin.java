package com.example.project;

public interface Admin {
    public Boolean isAdmin();
}
